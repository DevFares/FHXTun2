"""
core module initialization.
"""
