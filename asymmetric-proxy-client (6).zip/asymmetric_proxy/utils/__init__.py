"""
utils module initialization.
"""
